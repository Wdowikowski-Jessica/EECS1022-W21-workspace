package model;

public class OnlineSchool {
	private Participant[] list1;
	private Participant[] list2;
	private Participant[] list3;
	
}
