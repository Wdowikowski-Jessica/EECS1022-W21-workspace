package model;

public class Store {
	final int MAX_NUM_CAPACITY = 100;
	
	public void addZones(Zone[] input1) {
		
	}

	public Zone[] getZones() {
		return null;
	}

	public int[] getStats(String string) {
		return null;
	}

	public Zone[] getZones(int i) {
		return null;
	}

}
