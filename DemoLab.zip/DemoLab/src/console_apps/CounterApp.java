package console_apps;

import model.Counter;

public class CounterApp {

	public static void main(String[] args) {
		
		Counter c = new Counter();
		System.out.println(c);

	}

}
