package console_apps;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello EECS1022 W21!");
		System.out.println("Hello Jessica!");
	}

}
